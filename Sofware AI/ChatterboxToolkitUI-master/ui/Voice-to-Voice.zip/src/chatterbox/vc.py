from pathlib import Path
from typing import Optional
import librosa
import torch
import soundfile as sf
import numpy as np
import os

# --- Model Imports Logic ---
# یہ کوشش کرے گا کہ ماڈلز کو امپورٹ کرے، اگر فائلز نہیں ہیں تو ایرر دے گا
try:
    from .models.s3tokenizer import S3_SR
    from .models.s3gen import S3GEN_SR, S3Gen
except ImportError:
    # Fallback اگر ماڈلز فولڈر src میں نہیں مل رہا
    try:
        from src.chatterbox.models.s3tokenizer import S3_SR
        from src.chatterbox.models.s3gen import S3GEN_SR, S3Gen
    except ImportError:
         print("CRITICAL: Could not import S3Gen models. Ensure 'models' folder is inside 'src/chatterbox'")
         raise

class ChatterboxVC:
    ENC_COND_LEN = 6 * S3_SR
    DEC_COND_LEN = 10 * S3GEN_SR

    def __init__(
        self,
        s3gen: S3Gen,
        device: str,
        ref_dict: dict = None,
    ):
        self.sr = S3GEN_SR
        self.s3gen = s3gen
        self.device = device
        self.ref_dict = None
        
        if ref_dict:
             self.ref_dict = {
                k: v.to(device) if torch.is_tensor(v) else v
                for k, v in ref_dict.items()
            }

    @classmethod
    def from_local(cls, ckpt_dir, device, s3gen_cfg: Optional[dict] = None) -> 'ChatterboxVC':
        ckpt_dir = Path(ckpt_dir)
        print(f"Loading Chatterbox model from: {ckpt_dir} on {device}")
        
        # Load Reference Conditions (Generic Voice)
        ref_dict = None
        conds_path = ckpt_dir / "conds.pt"
        if conds_path.exists():
            # CPU پر لوڈ کریں پہلے تاکہ GPU میموری ایشو نہ ہو
            states = torch.load(conds_path, map_location='cpu')
            ref_dict = states.get('gen', {})
        else:
            print("Warning: conds.pt not found. Ensure models are downloaded correctly.")

        # Load S3Gen Model
        s3gen = S3Gen(cfg=s3gen_cfg)
        s3gen_path = ckpt_dir / "s3gen.safetensors"
        
        if s3gen_path.exists():
            from safetensors.torch import load_file
            # ماڈل ویٹس لوڈ کریں
            s3gen.load_state_dict(load_file(s3gen_path), strict=False)
        else:
            raise FileNotFoundError(f"Model file missing: {s3gen_path}")
        
        s3gen.to(device).eval()
        return cls(s3gen, device, ref_dict=ref_dict)

    def set_target_voice(self, wav_fpath):
        # دوست کی آواز یا ٹارگٹ وائس سیٹ کریں
        s3gen_ref_wav, _sr = librosa.load(wav_fpath, sr=S3GEN_SR)
        
        # اگر آڈیو بہت لمبی ہے تو کاٹ دیں
        if len(s3gen_ref_wav) > self.DEC_COND_LEN:
             s3gen_ref_wav = s3gen_ref_wav[:self.DEC_COND_LEN]
             
        self.ref_dict = self.s3gen.embed_ref(s3gen_ref_wav, S3GEN_SR, device=self.device)

    def generate(
        self,
        audio,
        target_voice_path=None,
        inference_cfg_rate: Optional[float] = None,
        sigma_min: Optional[float] = None,
    ):
        # سیٹنگز اپلائی کریں
        if inference_cfg_rate is not None or sigma_min is not None:
            self.s3gen.set_inference_params(
                inference_cfg_rate=inference_cfg_rate,
                sigma_min=sigma_min,
            )

        # ٹارگٹ وائس لوڈ کریں
        if target_voice_path:
            self.set_target_voice(target_voice_path)
        elif self.ref_dict is None:
            raise ValueError("Target voice path is required!")

        with torch.inference_mode():
            # ان پٹ آڈیو لوڈ کریں
            audio_16, _ = librosa.load(audio, sr=S3_SR)
            audio_16 = torch.from_numpy(audio_16).float().to(self.device)[None, ]

            # ٹوکنز بنائیں
            s3_tokens, _ = self.s3gen.tokenizer(audio_16)
            
            # فائنل آواز جنریٹ کریں
            wav, _ = self.s3gen.inference(
                speech_tokens=s3_tokens,
                ref_dict=self.ref_dict,
            )
            
            # واٹر مارک ہٹا دیا گیا ہے
            return wav.detach().cpu()

    def save_wav(self, wav_tensor: torch.Tensor, output_path: str):
        # آڈیو سیو کریں
        if wav_tensor.dim() == 3:
            wav_tensor = wav_tensor.squeeze(0)
        wav_numpy = wav_tensor.squeeze(0).numpy()
        sf.write(output_path, wav_numpy, self.sr)
